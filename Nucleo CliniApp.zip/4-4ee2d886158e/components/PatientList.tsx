
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
} from 'react-native';
import { IconSymbol } from '@/components/IconSymbol';
import { colors, commonStyles, typography, spacing } from '@/styles/commonStyles';
import { Patient } from '@/types';

interface PatientListProps {
  patients: Patient[];
  onPatientPress: (patient: Patient) => void;
  onAddPatient: () => void;
  loading?: boolean;
}

export default function PatientList({ patients, onPatientPress, onAddPatient, loading = false }: PatientListProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPatients = patients.filter(patient =>
    patient.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
    patient.valorId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderPatient = ({ item }: { item: Patient }) => (
    <TouchableOpacity
      style={[commonStyles.card, commonStyles.row, commonStyles.spaceBetween]}
      onPress={() => onPatientPress(item)}
      activeOpacity={0.7}
    >
      <View style={{ flex: 1 }}>
        <Text style={[typography.h3, { marginBottom: spacing.xs }]}>
          {item.nombre}
        </Text>
        <Text style={[typography.bodySecondary, { marginBottom: spacing.xs }]}>
          {item.tipoId.toUpperCase()}: {item.valorId}
        </Text>
        <View style={[commonStyles.row, { gap: spacing.md }]}>
          <Text style={typography.caption}>
            Visita N° {item.numeroVisita}
          </Text>
          {item.sillaAsignada && (
            <View style={[commonStyles.row, { alignItems: 'center', gap: spacing.xs }]}>
              <View style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: colors.occupied,
              }} />
              <Text style={[typography.caption, { color: colors.occupied }]}>
                Silla {item.sillaAsignada.replace('silla-', '')}
              </Text>
            </View>
          )}
        </View>
      </View>
      <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
    </TouchableOpacity>
  );

  const renderEmptyState = () => (
    <View style={[commonStyles.center, { flex: 1, paddingVertical: spacing.xxl }]}>
      <IconSymbol name="person.3" size={64} color={colors.textSecondary} />
      <Text style={[typography.h3, { marginTop: spacing.md, marginBottom: spacing.sm }]}>
        {searchQuery ? 'No se encontraron pacientes' : 'No hay pacientes registrados'}
      </Text>
      <Text style={[typography.bodySecondary, { textAlign: 'center', marginBottom: spacing.lg }]}>
        {searchQuery 
          ? 'Intenta con otro término de búsqueda'
          : 'Comienza agregando tu primer paciente'
        }
      </Text>
      {!searchQuery && (
        <TouchableOpacity
          style={[commonStyles.button, commonStyles.buttonPrimary]}
          onPress={onAddPatient}
        >
          <Text style={commonStyles.buttonText}>Agregar Paciente</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <View style={{ flex: 1 }}>
      {/* Header */}
      <View style={[commonStyles.row, commonStyles.spaceBetween, { paddingHorizontal: spacing.md, paddingVertical: spacing.sm }]}>
        <Text style={typography.h1}>Pacientes</Text>
        <TouchableOpacity
          style={{
            backgroundColor: colors.primary,
            borderRadius: 20,
            width: 40,
            height: 40,
            justifyContent: 'center',
            alignItems: 'center',
          }}
          onPress={onAddPatient}
        >
          <IconSymbol name="plus" size={24} color={colors.card} />
        </TouchableOpacity>
      </View>

      {/* Search Bar */}
      <View style={{ paddingHorizontal: spacing.md, marginBottom: spacing.md }}>
        <View style={[commonStyles.input, commonStyles.row, { alignItems: 'center', gap: spacing.sm }]}>
          <IconSymbol name="magnifyingglass" size={20} color={colors.textSecondary} />
          <TextInput
            style={[typography.body, { flex: 1, color: colors.text }]}
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Buscar por nombre o RUT..."
            placeholderTextColor={colors.textSecondary}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <IconSymbol name="xmark.circle.fill" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Patient List */}
      <FlatList
        data={filteredPatients}
        renderItem={renderPatient}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{
          paddingHorizontal: spacing.md,
          paddingBottom: 100, // Space for floating tab bar
          flexGrow: 1,
        }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={renderEmptyState}
        refreshing={loading}
        onRefresh={() => {
          // Refresh functionality can be added here
          console.log('Refreshing patients...');
        }}
      />
    </View>
  );
}
