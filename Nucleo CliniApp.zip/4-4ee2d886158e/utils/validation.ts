
import { FormErrors, PatientFormData } from '@/types';

export const validateRUT = (rut: string): boolean => {
  // Remove dots and hyphens
  const cleanRUT = rut.replace(/[.-]/g, '');
  
  if (cleanRUT.length < 8 || cleanRUT.length > 9) {
    return false;
  }
  
  const body = cleanRUT.slice(0, -1);
  const dv = cleanRUT.slice(-1).toLowerCase();
  
  // Check if body contains only numbers
  if (!/^\d+$/.test(body)) {
    return false;
  }
  
  // Calculate verification digit
  let sum = 0;
  let multiplier = 2;
  
  for (let i = body.length - 1; i >= 0; i--) {
    sum += parseInt(body[i]) * multiplier;
    multiplier = multiplier === 7 ? 2 : multiplier + 1;
  }
  
  const remainder = sum % 11;
  const calculatedDV = remainder === 0 ? '0' : remainder === 1 ? 'k' : (11 - remainder).toString();
  
  return dv === calculatedDV;
};

export const formatRUT = (rut: string): string => {
  // Remove all non-alphanumeric characters
  const clean = rut.replace(/[^0-9kK]/g, '');
  
  if (clean.length <= 1) return clean;
  
  // Separate body and verification digit
  const body = clean.slice(0, -1);
  const dv = clean.slice(-1);
  
  // Add dots to body
  const formattedBody = body.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  
  return `${formattedBody}-${dv}`;
};

export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePhone = (phone: string): boolean => {
  // Chilean phone format: +569XXXXXXXX
  const phoneRegex = /^\+569\d{8}$/;
  return phoneRegex.test(phone);
};

export const formatPhone = (phone: string): string => {
  // Remove all non-numeric characters
  const clean = phone.replace(/\D/g, '');
  
  // If it starts with 569, add the +
  if (clean.startsWith('569') && clean.length === 11) {
    return `+${clean}`;
  }
  
  // If it's 9 digits starting with 9, add +569
  if (clean.startsWith('9') && clean.length === 9) {
    return `+56${clean}`;
  }
  
  // If it's 8 digits, add +569
  if (clean.length === 8) {
    return `+569${clean}`;
  }
  
  return phone;
};

export const validatePatientForm = (data: PatientFormData): FormErrors => {
  const errors: FormErrors = {};
  
  // Validate name
  if (!data.nombre.trim()) {
    errors.nombre = 'El nombre es obligatorio';
  } else if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(data.nombre.trim())) {
    errors.nombre = 'El nombre solo puede contener letras';
  }
  
  // Validate birth date
  if (!data.fechaNacimiento) {
    errors.fechaNacimiento = 'La fecha de nacimiento es obligatoria';
  } else {
    const birthDate = new Date(data.fechaNacimiento);
    const today = new Date();
    if (birthDate > today) {
      errors.fechaNacimiento = 'La fecha de nacimiento no puede ser futura';
    }
  }
  
  // Validate ID
  if (!data.valorId.trim()) {
    errors.valorId = 'La identificación es obligatoria';
  } else if (data.tipoId === 'rut' && !validateRUT(data.valorId)) {
    errors.valorId = 'RUT inválido';
  }
  
  // Validate phone (optional)
  if (data.telefono && !validatePhone(data.telefono)) {
    errors.telefono = 'Teléfono debe tener formato +569XXXXXXXX';
  }
  
  // Validate email (optional)
  if (data.correo && !validateEmail(data.correo)) {
    errors.correo = 'Formato de correo inválido';
  }
  
  return errors;
};

export const calculateAge = (birthDate: string): number => {
  const birth = new Date(birthDate);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
};

export const formatDuration = (minutes: number): string => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours === 0) {
    return `${mins}m`;
  }
  
  return `${hours}h ${mins}m`;
};
