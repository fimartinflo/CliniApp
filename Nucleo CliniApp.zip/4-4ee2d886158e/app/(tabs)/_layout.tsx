
import React from 'react';
import { Platform } from 'react-native';
import { NativeTabs, Icon, Label } from 'expo-router/unstable-native-tabs';
import { Stack } from 'expo-router';
import FloatingTabBar, { TabBarItem } from '@/components/FloatingTabBar';
import { colors } from '@/styles/commonStyles';

export default function TabLayout() {
  // Define the tabs configuration
  const tabs: TabBarItem[] = [
    {
      name: 'pacientes',
      route: '/(tabs)/pacientes',
      icon: 'person.3.fill',
      label: 'Pacientes',
    },
    {
      name: 'sillones',
      route: '/(tabs)/sillones',
      icon: 'bed.double.fill',
      label: 'Sillones',
    },
  ];

  // Use NativeTabs for iOS, custom FloatingTabBar for Android and Web
  if (Platform.OS === 'ios') {
    return (
      <NativeTabs>
        <NativeTabs.Trigger name="pacientes">
          <Icon sf="person.3.fill" drawable="ic_people" />
          <Label>Pacientes</Label>
        </NativeTabs.Trigger>
        <NativeTabs.Trigger name="sillones">
          <Icon sf="bed.double.fill" drawable="ic_chair" />
          <Label>Sillones</Label>
        </NativeTabs.Trigger>
      </NativeTabs>
    );
  }

  // For Android and Web, use Stack navigation with custom floating tab bar
  return (
    <>
      <Stack
        screenOptions={{
          headerShown: false,
          animation: 'none', // Remove fade animation to prevent black screen flash
        }}
      >
        <Stack.Screen name="pacientes" />
        <Stack.Screen name="sillones" />
      </Stack>
      <FloatingTabBar tabs={tabs} />
    </>
  );
}
