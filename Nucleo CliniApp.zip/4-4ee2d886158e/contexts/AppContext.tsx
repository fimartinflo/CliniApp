
import React, { createContext, useContext, ReactNode } from 'react';
import { useStorage } from '@/hooks/useStorage';
import { Patient, Chair, VisitHistory } from '@/types';

interface AppContextType {
  // Data
  patients: Patient[];
  chairs: Chair[];
  visitHistory: VisitHistory[];
  loading: boolean;
  
  // Patient methods
  addPatient: (patientData: Omit<Patient, 'id' | 'numeroVisita' | 'fechaCreacion' | 'fechaActualizacion'>) => Promise<Patient>;
  updatePatient: (patientId: string, updates: Partial<Patient>) => Promise<void>;
  
  // Chair methods
  assignPatientToChair: (patientId: string, chairId: string) => Promise<void>;
  releaseChair: (chairId: string) => Promise<any>;
  
  // History methods
  getPatientHistory: (patientId: string) => VisitHistory[];
  
  // Utility methods
  loadData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const storage = useStorage();

  const value: AppContextType = {
    ...storage,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};
