
import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Patient, Chair, VisitHistory } from '@/types';

const STORAGE_KEYS = {
  PATIENTS: '@cliniapp_patients',
  CHAIRS: '@cliniapp_chairs',
  VISIT_HISTORY: '@cliniapp_visit_history',
  PATIENT_COUNTER: '@cliniapp_patient_counter',
};

export const useStorage = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [chairs, setChairs] = useState<Chair[]>([]);
  const [visitHistory, setVisitHistory] = useState<VisitHistory[]>([]);
  const [loading, setLoading] = useState(true);

  // Initialize storage
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load patients
      const patientsData = await AsyncStorage.getItem(STORAGE_KEYS.PATIENTS);
      if (patientsData) {
        setPatients(JSON.parse(patientsData));
      }
      
      // Load chairs
      const chairsData = await AsyncStorage.getItem(STORAGE_KEYS.CHAIRS);
      if (chairsData) {
        setChairs(JSON.parse(chairsData));
      } else {
        // Initialize with 6 chairs if none exist
        const initialChairs: Chair[] = Array.from({ length: 6 }, (_, i) => ({
          id: `silla-${i + 1}`,
          estado: 'libre' as const,
        }));
        setChairs(initialChairs);
        await AsyncStorage.setItem(STORAGE_KEYS.CHAIRS, JSON.stringify(initialChairs));
      }
      
      // Load visit history
      const historyData = await AsyncStorage.getItem(STORAGE_KEYS.VISIT_HISTORY);
      if (historyData) {
        setVisitHistory(JSON.parse(historyData));
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const savePatients = async (newPatients: Patient[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(newPatients));
      setPatients(newPatients);
    } catch (error) {
      console.error('Error saving patients:', error);
    }
  };

  const saveChairs = async (newChairs: Chair[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.CHAIRS, JSON.stringify(newChairs));
      setChairs(newChairs);
    } catch (error) {
      console.error('Error saving chairs:', error);
    }
  };

  const saveVisitHistory = async (newHistory: VisitHistory[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.VISIT_HISTORY, JSON.stringify(newHistory));
      setVisitHistory(newHistory);
    } catch (error) {
      console.error('Error saving visit history:', error);
    }
  };

  const getNextPatientNumber = async (): Promise<number> => {
    try {
      const counterData = await AsyncStorage.getItem(STORAGE_KEYS.PATIENT_COUNTER);
      const currentCounter = counterData ? parseInt(counterData, 10) : 0;
      const nextCounter = currentCounter + 1;
      await AsyncStorage.setItem(STORAGE_KEYS.PATIENT_COUNTER, nextCounter.toString());
      return nextCounter;
    } catch (error) {
      console.error('Error getting patient number:', error);
      return 1;
    }
  };

  const addPatient = async (patientData: Omit<Patient, 'id' | 'numeroVisita' | 'fechaCreacion' | 'fechaActualizacion'>) => {
    try {
      const id = `patient-${Date.now()}`;
      const numeroVisita = await getNextPatientNumber();
      const now = new Date().toISOString();
      
      const newPatient: Patient = {
        ...patientData,
        id,
        numeroVisita,
        fechaCreacion: now,
        fechaActualizacion: now,
      };
      
      const updatedPatients = [...patients, newPatient];
      await savePatients(updatedPatients);
      return newPatient;
    } catch (error) {
      console.error('Error adding patient:', error);
      throw error;
    }
  };

  const updatePatient = async (patientId: string, updates: Partial<Patient>) => {
    try {
      const updatedPatients = patients.map(patient =>
        patient.id === patientId
          ? { ...patient, ...updates, fechaActualizacion: new Date().toISOString() }
          : patient
      );
      await savePatients(updatedPatients);
    } catch (error) {
      console.error('Error updating patient:', error);
      throw error;
    }
  };

  const assignPatientToChair = async (patientId: string, chairId: string) => {
    try {
      const now = new Date().toISOString();
      
      // Update chair
      const updatedChairs = chairs.map(chair =>
        chair.id === chairId
          ? { ...chair, estado: 'ocupado' as const, pacienteId, horaInicio: now }
          : chair
      );
      
      // Update patient
      const updatedPatients = patients.map(patient =>
        patient.id === patientId
          ? { ...patient, sillaAsignada: chairId, fechaActualizacion: now }
          : patient
      );
      
      await Promise.all([
        saveChairs(updatedChairs),
        savePatients(updatedPatients),
      ]);
    } catch (error) {
      console.error('Error assigning patient to chair:', error);
      throw error;
    }
  };

  const releaseChair = async (chairId: string) => {
    try {
      const chair = chairs.find(c => c.id === chairId);
      if (!chair || chair.estado === 'libre') return;
      
      const now = new Date().toISOString();
      const startTime = new Date(chair.horaInicio!).getTime();
      const endTime = new Date(now).getTime();
      const duration = Math.floor((endTime - startTime) / (1000 * 60)); // minutes
      
      // Create visit history entry
      const historyEntry: VisitHistory = {
        id: `visit-${Date.now()}`,
        pacienteId: chair.pacienteId!,
        sillaId: chairId,
        fechaInicio: chair.horaInicio!,
        fechaFin: now,
        duracion: duration,
      };
      
      // Update chair
      const updatedChairs = chairs.map(c =>
        c.id === chairId
          ? { ...c, estado: 'libre' as const, pacienteId: undefined, horaInicio: undefined, horaFin: now, duracion }
          : c
      );
      
      // Update patient
      const updatedPatients = patients.map(patient =>
        patient.id === chair.pacienteId
          ? { ...patient, sillaAsignada: undefined, fechaActualizacion: now }
          : patient
      );
      
      // Update visit history
      const updatedHistory = [...visitHistory, historyEntry];
      
      await Promise.all([
        saveChairs(updatedChairs),
        savePatients(updatedPatients),
        saveVisitHistory(updatedHistory),
      ]);
      
      return { patient: updatedPatients.find(p => p.id === chair.pacienteId), duration };
    } catch (error) {
      console.error('Error releasing chair:', error);
      throw error;
    }
  };

  const getPatientHistory = (patientId: string): VisitHistory[] => {
    return visitHistory.filter(visit => visit.pacienteId === patientId);
  };

  return {
    patients,
    chairs,
    visitHistory,
    loading,
    addPatient,
    updatePatient,
    assignPatientToChair,
    releaseChair,
    getPatientHistory,
    loadData,
  };
};
